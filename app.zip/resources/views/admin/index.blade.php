@extends('admin.layouts.app')

@section('content')
@endsection

@section('css')
@endsection

@section('meta')
    <title>Panel</title>
@endsection

@section('js')
@endsection
