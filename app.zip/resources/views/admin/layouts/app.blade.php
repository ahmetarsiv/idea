<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="dc.language" content="{{ app()->getLocale() }}">
    <meta http-equiv="content-language" content="{{ app()->getLocale() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Blogger admin">
    <meta name="author" content="Ahmet Arşiv">
    <meta name="generator" content="ArsivPro">
    @yield('meta')

    <link rel="icon" href="{{asset('images/favicon.png')}}" type="image/x-icon"/>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    @yield('css')
</head>
<body>

<div class="d-flex" id="wrapper">
    <!-- Sidebar-->
    <div class="border-end d-flex d-sm-flex" id="sidebar-wrapper">
        <div class="sidebar-heading">
            <div class="list-group list-group-flush sidebar-menu">

                <a class="sidebar-logo-link d-md-none d-lg-none d-xl-none d-xxl-none" href="#">
                    <img class="sidebar-logo" src="{{asset('images/laerx.png')}}" alt="logo">
                </a>

                <a class="sidebar-menu-list">
                    <a class="list-group-item list-group-item-action {{ request()->is('admin/blog*', 'admin/category*') ? 'active' : '' }}" type="button" id="dropdownMenuButton3" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-pencil-square fs-4"></i>
                        <span class="sidebar-menu-text">Blog</span>
                        <i class="bi bi-chevron-down sidebar-toggle-icon me-1"></i>
                    </a>
                    <ul class="dropdown-menu sidebar-dropdown-open" aria-labelledby="dropdownMenuButton3">
                        <span class="text-secondary ms-2">POST</span>
                        <li><a class="dropdown-item" href="{{route('admin.blog.index')}}">Blog</a></li>
                        <li><a class="dropdown-item" href="{{route('admin.category.index')}}">Kategoriler</a></li>
                    </ul>

                    <a class="list-group-item list-group-item-action {{ request()->is('admin/cms*') ? 'active' : '' }}"
                       href="{{route('admin.cms.index')}}">
                        <i class="bi bi-cast fs-4"></i>
                        <span class="sidebar-menu-text">CMS</span>
                    </a>

                    <a class="list-group-item list-group-item-action {{ request()->is('admin/locale*') ? 'active' : '' }}"
                       href="{{route('admin.locale.index')}}">
                        <i class="bi bi-translate fs-4"></i>
                        <span class="sidebar-menu-text">Dil Seçenekleri</span>
                    </a>

                    <a class="list-group-item list-group-item-action {{ request()->is('admin/slider*') ? 'active' : '' }}"
                       href="{{route('admin.slider.index')}}">
                        <i class="bi bi-image-alt fs-4"></i>
                        <span class="sidebar-menu-text">Slider</span>
                    </a>
                </a>

            </div>
        </div>
    </div>
    <div class="sidebar-toggle-button">
        <a class="btn btn-light" id="sidebarToggle"><i class="bi bi-list fs-4"></i></a>
    </div>
    <!-- Page content wrapper-->
    <div id="page-content-wrapper">
        <!-- Top navigation-->
        <nav class="navbar-top navbar navbar-expand-lg navbar-light border-bottom d-none d-md-block">
            <div class="container-fluid">

                <a class="navbar-logo-link" href="{{ route('admin.dashboard') }}">
                    <img class="sidebar-logo" src="{{asset('images/laerx.png')}}" alt="logo">
                </a>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                        <li class="nav-item me-2">
                            <a class="nav-link navbar-border">
                                <i class="bi bi-bell fs-4 ms-2"></i>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link navbar-border" id="navbarDropdown" href="#" role="button"
                               data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i
                                    class="bi bi-person-circle fs-4"></i>
                                <span class="name">{{auth()->user()->name .' '. auth()->user()->surname}}</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end navbar-dropdown-open" aria-labelledby="navbarDropdown">
                                <span class="text-secondary ms-2">Version : {{ app()->version() }}</span>
                                <a class="dropdown-item" href="{{ route('admin.profile.edit') }}">Profil</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ route('admin.logout') }}">Çıkış Yap</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content-app">
            @yield('content')
        </div>

        <nav class="navbar fixed-bottom bottom-navigation-mb justify-content-around d-flex d-md-none d-lg-none d-xl-none d-xxl-none">
            <ul class="navbar-list mx-auto ">
                <li class="navbar-item">
                    <a class="navbar-link" id="sidebarToggleM" >
                        <i class="bi bi-list navbar-link-icon"></i>
                    </a>
                </li>

                <li class="navbar-item">
                    <a class="navbar-link {{ request()->is('admin/company*') ? 'active' : '' }}" href="#">
                        <i class="bi bi-building navbar-link-icon"></i>
                    </a>
                </li>

                <li class="navbar-item">
                    <a class="navbar-link {{ request()->is('admin/dashboard') ? 'active' : '' }}" href="#">
                        <i class="bi bi-house navbar-link-icon"></i>
                    </a>
                </li>

                <li class="navbar-item">
                    <a class="navbar-link {{ request()->is('admin/manager-user*') ? 'active' : '' }}" href="#">
                        <i class="bi bi-people navbar-link-icon"></i>
                    </a>
                </li>

                <li class="navbar-item">
                    <a class="navbar-link {{ request()->is('admin/profile*') ? 'active' : '' }}" href="#">
                        <i class="bi bi-person navbar-link-icon"></i>
                    </a>
                </li>


                <div class="navbar-underscore"></div>
            </ul>
        </nav>
    </div>
</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/vanilla-masker@1.1.1/build/vanilla-masker.min.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="{{ asset('js/app.js') }}"></script>
@yield('js')
</html>
